# -*- coding: utf-8 -*-
# @Tme    : 2020/12/01 16:00
# @Author  : zhiming.qian
# @Email   : zhimingqian@tencent.com

from mvt.utils.runtime_util import collect_env


if __name__ == '__main__':
    print(collect_env())

