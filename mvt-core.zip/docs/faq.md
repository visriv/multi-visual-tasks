# FAQ

We list some common issues faced by many users and their corresponding solutions here.
Feel free to enrich the list if you find any frequent issues and have ways to help others to solve them.


## Training

- **TypeError: cannot pickle '_thread._local' object**

  Set WORKERS_PER_DEVICE as 0
