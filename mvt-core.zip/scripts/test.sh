python3 tools/test.py task_settings/img_det/det_yolov4_retail_one.yaml meta/train_infos/det_yolov4_retail_one/epoch_200.pth --eval 'mAP'
