python3 tools/test.py \
    task_settings/img_emb/emb_resnet50_fc_retail_xu.yaml \
    meta/train_infos/emb_resnet50_fc_retail_xu/epoch_6.pth --eval 'mAP'
