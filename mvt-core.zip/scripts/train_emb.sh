python3 ./tools/train.py --work-dir meta/train_infos --no-test \
    task_settings/img_emb/emb_resnet50_fc_retail_xu.yaml
