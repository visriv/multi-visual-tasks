python3 ./tools/train.py --work-dir meta/train_infos --no-test \
    --load-from meta/train_infos/det_yolov4_retail_one_v0/epoch_200.pth \
    task_settings/img_det/det_yolov4_retail_one.yaml 
