from .imgcls_embedder import ImgClsEmbedder

__all__ = ['ImgClsEmbedder']
